这些测试用例来源自https://github.com/munificent/craftinginterpreters/tree/master/test
但是由于cploxplox和原始的lox有一些语法出入，因此我对所有用例做了针对性修改，包括：
1. 注释由//改为#
2. 函数声明由fun改为func
3. print从语法变为函数
4. 继承由<改为>